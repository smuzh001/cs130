#ifndef __THE_GLOBALS_H__
#define __THE_GLOBALS_H__

#define X 0
#define Y 1
#define Z 2

#define A 0
#define B 1
#define C 2

#endif
